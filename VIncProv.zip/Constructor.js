function Country(name, img, x, y) {
  this.name = name
  this.img = loadImage(img)
  this.x = x
  this.y = y
  this.owner = 0
  this.invade = function() {
    if ((abs(mouseX - (this.x + loc.x)) < textWidth(this.name) / 2) && (abs(mouseY - (this.y + loc.y)) < titleSize)) {
      this.owner++;
      if (this.owner > owners.length - 1) {
        this.owner = 0
      }
    }
  }
}

function Owner(name, col) {
  this.name = name
  this.col = col
  this.printTitle = function(y) {
    textSize(titleSize + 5);
    fill(this.col)
    stroke("black")
    textAlign(RIGHT, TOP)
    text(this.name, width * (.99 / loc.scle), y + (loc.scle*5))
  }
}